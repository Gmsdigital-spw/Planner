# Trading Floor V6 spec — Alpaca day trading, paper first

_Standing instructions written with Grayson on Oct 20, 2026; updated Oct 23, 2026 (pre-trade risk check, nightly journal review, daily plan checklist, data-only rules, go-live checklist; see "Rules added Oct 23, 2026" below). Not financial advice: even with every rule here the account can lose the $25. The floor is built and gated; nothing trades until the key tap and a separate "paper go", and nothing trades real money until a separate "live go" with its own key._

## The money rules (enforced twice: in the gateway code `gw/run.py` op `alpaca`, and in the run prompt)
| Rule | Value |
|---|---|
| Deposit | $25 (paper money for the first 2 trading days) |
| Hard floor | $20: equity at or below the floor = every new buy is refused by the gateway, open positions are closed, the floor stays locked until Grayson resets it |
| Max total loss | $5, by construction (deposit − floor) |
| Risk per trade | 2% of equity ($0.50 on $25) |
| Stop-loss | on every buy, placed with the entry as a bracket order; a buy without one is refused |
| Take-profit | at least 2:1 reward-to-risk or the trade is skipped |
| Position size | risk ÷ (entry − stop) in notional dollars (fractional shares); max 40% of cash in one name; max 2 open positions |
| Hours | buys 8:35 AM to 2:45 PM Central only (market opens 8:30 CT); everything flat by 2:45 PM; no overnight holds; day orders only |
| Daily loss limit | $1.50 (6% of $25): hit it and Bear closes the day |
| No margin | cash only; buying power = cash; never short, never options, never crypto |
| Paper → live | 2 paper trading days (Grayson shortened it from 14 on Oct 20, 2026) with the report below, then Grayson's separate "live go"; live uses a different key and the ALPACA_LIVE variable set to 1 by Grayson himself |

## The crew
- **Bull** — finds long setups in liquid large-cap names and ETFs only (price above $5, average volume high, tight spread): trend on the 5-minute chart + a pullback to a level, entry on the first green bar, stop under the pullback low, target at 2R; every level from 5-minute bars fetched in the same run ("Chart analysis" below). Writes each idea as a TradePlan: symbol, entry, stop, target, R:R, size, one-sentence reason, confidence (decision → number → next action).
- **Bear** — the risk officer. Checks every plan against the rules table and the pre-trade risk check (below) before any order; owns the floor, the daily loss limit, the 2:45 PM flatten; the only one allowed to lock or (never without Grayson) unlock the floor. Bear's "no" ends the discussion.
- **Vault** — the ledger: every order, fill, fee, slippage, equity curve, drawdown; writes modules/trading/ledger/<day> and the running 2-day paper report (win rate, average R, max drawdown, biggest loss, rule breaches = must be 0); runs the nightly trade-journal review (below) in the close run.
- **Tape** — the morning read in plain English: what the market did yesterday, what is on the calendar today (earnings, Fed, CPI), what the crew will and will not touch. Uses the glossary words and explains each one the first time it appears in a day. Owns the daily plan checklist (below); the read sets only the bias and the avoid list, never a price target.

## Glossary (the words every agent uses correctly)
stocks, equities, ETF, portfolio, equity (account value), cash balance, buying power, bullish, bearish, trend, pullback, support, resistance, volatility, liquidity, spread, slippage, entry, market order, limit order, stop-loss, take-profit, bracket order, trailing stop, risk-to-reward (R:R), position sizing, max exposure, drawdown, daily loss limit, fractional shares, day trade, PDT rule (under $25k: at most 3 day trades in 5 business days on a margin account; this account is cash-only, so settlement rules apply instead), compounding, reinvestment, paper trading, fill, partial fill, flat.

## Data and orders (through the free GitHub gateway, never Make)
- Op: `{"op":"alpaca","method":"GET","path":"/account"}`, `/positions`, `/orders?status=open`, `/clock`; data reads `{"op":"alpaca","data":true,"path":"/stocks/<SYM>/bars?timeframe=5Min&limit=60"}`; a buy `{"op":"alpaca","method":"POST","path":"/orders","body":{"symbol":"SPY","notional":"9.50","side":"buy","type":"limit","limit_price":"...","time_in_force":"day","order_class":"bracket","stop_loss":{"stop_price":"..."},"take_profit":{"limit_price":"..."}}}`; flatten `{"op":"alpaca","method":"DELETE","path":"/positions"}`.
- Secrets Grayson adds in GitHub (repo Settings → Secrets → Actions): `ALPACA_KEY_ID`, `ALPACA_SECRET_KEY` (PAPER keys). Variables: `ALPACA_FLOOR` (default 20), `ALPACA_LIVE` (default empty = paper).

## The paper report (2 trading days) (Vault, in the app under the Trading Floor)
Per day: trades, wins, losses, net P/L, max drawdown, rule breaches. Totals: win rate, average R, expectancy, worst day, best day, breaches (must be 0 to be allowed to ask for live). The report never predicts; it describes.

## The Trading run (the V6 prompt as saved Oct 20, 2026; superseded in practice by the V7 flow of Oct 21: the autopilot trades and owns the 2:45 flatten, the scans run hourly 8:41 to 14:41, the close run fires about 14:30 and verifies; see the daily plan checklist below)
Schedule: weekdays 9:25 AM Central (one run; a second run at 2:30 PM Central only to flatten and write the ledger). Prompt summary: read this spec and factory/skills/{bull,bear,vault,tape}/SKILL.md; read modules/trading/settings/main ({paused, paperDay, floorLocked}); if paused or floorLocked, write the ledger line and stop; Tape writes the read; Bull proposes at most 2 plans; Bear checks each against the table (any failure = skipped, logged with the rule); orders go through the gateway as bracket orders in notional dollars; Vault records fills and equity; at 2:30 PM flatten everything, write modules/trading/ledger/<day> and the running report, then Vault's nightly trade-journal review (factory/trading/journal/<day>.md, or factory/skills/vault/journal-<day>.md until the close task's write list allows the folder; 3 rules and one "What I've learned" line; section below), append one line to fleet/commander/audit/<day> (who "Bear", mod "trading"); message Grayson at most 3 lines only when a rule tripped, the floor locked, or the 2 paper days are done. Never add money, never change the floor, never switch to live, never trade outside the hours, never touch any other floor's collections.


## The Trading lab (nightly backtests on days the bot has never seen) — added with Grayson Oct 20, 2026
- **What:** `factory/trading/backtest.py` replays the exact strategy on real past 5-minute bars (free Alpaca IEX feed) as a $25 account with every rule and a realistic cost per trade (spread + slippage). It runs in the free GitHub Action "Trading lab" when a job is pushed to `factory/trading/lab/jobs/`. Each result reports trades, win rate, average R, profit factor (gross profit ÷ gross loss from the replayed trades, after costs; added Oct 23, 2026; `null` when no trade lost, never a made-up value), net P/L, max drawdown and breaches.
- **Honest test (walk-forward):** each job has TUNE days (where candidate settings are compared) and HOLDOUT days (never used for tuning). A change is only "adoptable" if, on the HOLDOUT days, it beats the current settings on net P/L and average R, with 20+ trades, no worse drawdown and 0 breaches.
- **Adoption:** only the Trading lab run writes `factory/trading/params.json`, and only after a change has been adoptable on TWO different holdout sets in a row. Bull uses params.json values where set (and its `setupNote` when a new setup type was adopted). The lab can never change the money rules (bankroll, floor, 2% risk, 40% cap, 2 positions, $1.50 daily loss, 2:1 minimum, flat by 2:45).
- **Live gate:** the crew does not recommend "live go" until the latest lab result for the CURRENT params shows positive net P/L on its holdout days with 20+ trades. First result (Oct 20, 2026, baseline): tune 22 trades / 31.8% wins / −$0.36; holdout 30 trades / 20% wins / −$1.06. Not ready. Latest (lab-2026-10-22, current params): holdout 28 trades / 14.3% wins / avg R −0.29 / −$0.54 / drawdown $0.54 / 0 breaches. Not ready. The full gate is the go-live readiness checklist below.

## Rules added Oct 23, 2026 (from Grayson's review of 7 outside "stock trading automation" prompts; only the parts that run on real Alpaca data were kept, rewritten as agent rules)

### No number without data (all four agents, every run)
- Every number in a plan, verdict, ledger line, report, journal, skill line or message names the source read in the SAME run: a gateway result (`/bankroll`, `/positions`, `/orders`, `/clock`, bars, snapshots), the autopilot's day file or heartbeat, a lab result file, or the database record it was written to earlier.
- Source missing or failed = write `unknown (source: <where it will come from>)`. Never an estimate, a rounded guess, a remembered price, a level from the news, or a number copied from an older day.
- A number with no source goes in the ledger's `reportSlips` list with who wrote it; `breaches` stays for money-rule breaches only, so the paper report's "mechanics OK" verdict keeps its meaning.

### Bear: pre-trade risk check (before any order the crew sends; and on every autopilot entry at the next scan)
Read `/bankroll`, `/positions`, `/orders?status=open` and, for today's realized loss, the day file's `trades[]` (or `/orders?status=closed&after=<today 8:30 CT>`) first; the check uses only those numbers. Any line fails = "NO + the line", no order. On the next scan Bear re-checks each autopilot buy from what the day file recorded (positions open at that minute, their stops, the notional): a buy that broke a money rule is a breach; one that fails only Bear's arithmetic (lines 1 to 4) goes in the ledger's `bearFlags` list, not `breaches`. Floor room is checked live only.
1. **Floor room** = equity − $20 floor − open risk, where open risk = Σ (entry − current stop) × qty over open positions. Floor room must exceed this plan's risk dollars (2% of equity), so the account stays above the floor even if every stop fills. Floor room under $1.00 is a warning Bear sends Grayson once that day (one line), not an entry rule: the coded floor is $20 and only Grayson changes money rules.
2. **Day room** = $1.50 daily loss limit − today's realized loss (closed trades) − open risk. Day room must exceed this plan's risk dollars.
3. **Open exposure**: open positions + this one ≤ 2. SPY, QQQ, DIA and IWM count as ONE bet (the one-bet rule, same words everywhere): the combined open risk across them stays within one trade's 2% of equity, and a second index ETF while another is open is at most half size; Bull sizes it so, Bear checks it, Vault's journal flags "combined index risk over 2%".
4. **Max loss vs floor**: equity − open risk − this plan's risk must stay above $20; otherwise NO, whatever the setup looks like.
5. **The rules table** as before: a stop at least 0.3% under entry, target ≥ 2:1, notional ≤ 40% of cash and ≤ cash, 8:35 AM–2:45 PM CT, day order, not on today's avoid list.
Bear writes one line per plan: `GO|NO <SYM>: floor room $x.xx, day room $x.xx, exposure n/2 (index bet $x.xx of $x.xx), max loss to floor $x.xx` (numbers from this run's gateway reads). In code today the autopilot and gateway enforce: the floor (equity at or below $20 = no buys, flatten and lock), the $1.50 daily loss limit on day P/L marked to market (realized + open, equity minus equityOpen), a stop on every buy, the 40% cap, the hours, 2 positions and 4 entries. The open-risk arithmetic of lines 1, 2 and 4 and the one-bet rule of line 3 are Bear's checks, not yet code.

### Bull: chart analysis only from bars fetched this run
- Every level (VWAP, 20-bar average, pullback low, opening-range high and low, entry, stop, target) is computed from 5-minute bars fetched through the gateway in this run (`/stocks/bars?symbols=...&timeframe=5Min&feed=iex`, start = today's 8:30 CT open) plus the latest trade (`/stocks/<SYM>/trades/latest?feed=iex`). Bull names the bar time each level came from.
- Fewer than 4 completed bars since the open, or a failed bars job = `no data: <reason>`, no plan. A 20-bar average exists only once 20 completed bars exist today (10:10 CT); before that it is `unknown (source: bars)` and no pullback plan is possible (the autopilot's own setup fires from the 22nd bar, about 10:20). Never yesterday's bars, a remembered level, a round number, or a level from the news or the read (this supersedes the Oct 21 note about fetching with start = prior day).
- A TradePlan lists: symbol, bars used (count, first and last bar time), entry, stop (which bar's low it sits under), target, R:R, size, one-sentence reason, confidence. Decision → number → next action.

### Tape: the daily plan checklist (all times Central; the read sets the bias and the avoid list, nothing else)
| When | Who | What, and where the numbers come from |
|---|---|---|
| 8:00–8:30 pre-market | Autopilot | Runner starts (cron 13:00 UTC = 8:00 CDT, 7:00 CST from Nov 1; then every 10 minutes as a safety net); heartbeat says "waiting for the open"; no orders. |
| 8:30 open | Autopilot | Bars from 8:30; buys only from 8:35 (money rule). The pullback setup in code can fire at the earliest on the 22nd completed 5-minute bar (20 for the average, 1 before it, plus the signal bar; backtest.setup_at), so the first possible autopilot entry is about 10:20 CT (first buys: Oct 21 10:54, Oct 22 10:20). Bull's scan rule: no plan on fewer than 4 completed bars. |
| 8:41 first scan | Tape | The read: WebSearch for what moved yesterday and premarket, today's calendar (Fed, CPI, jobs, FOMC with times), earnings today and after close; one gateway job of snapshots for SPY, QQQ, IWM and 15–25 liquid names. Output = bias (bullish / bearish / choppy, with the SPY and QQQ numbers from the snapshots) + the avoid list (earnings today or after close, halts, gaps over 5% (a threshold set Oct 23, 2026; Tape excluded a −6% gap on Oct 21), the FOMC hour) → `factory/trading/watchlist.json` = {"day": <Central day key>, "symbols": [...], "avoid": [...]} (the autopilot ignores a file whose `day` is not today, avoid list included) and ledger.tape. No price target, no entry, no stop, no level: those come only from Bull's fetched bars. Kick file first. |
| 8:41 | Bear | Gates from the heartbeat, last-error file, `/bankroll` and `/positions`: heartbeat age under 30 minutes, equity and floor room, open positions; the pre-trade check on any entry already in the day file. |
| 8:41 | Vault | Ledger opened in ONE batch with equityOpen from `/bankroll` and the gate note. |
| hourly scans 9:41 to 14:41 | Bear | Day file `runs` advanced since the last scan; 0 actions with status ≥ 300 and 0 buys with status 207 (stop refused, sold at once); 0 exits with why `no stop` or `trail refused`; day room recomputed; flag Grayson once if a position sat without a stop for more than one cycle. |
| same scans | Tape | Refresh the read only if the mood clearly changed (SPY crossed its open the other way, or a calendar event hit); say what changed, with the numbers. |
| same scans | Vault | Autopilot trades and actions → ledger and the live board, real numbers only; exit times from `/orders?status=closed` (filled_at) when the day file has none. |
| same scans | Bull | Review each autopilot entry against the chart rule using bars fetched this run (was the setup there on that bar?); one learned line on the first and last run. |
| 14:00 | Autopilot | Last new entry (`last_entry_ct`). |
| close run, fires about 14:30 (MODE ≥ 14:15) and finishes after 14:45 | Bear | The autopilot owns the 2:45 flatten; the close run verifies `/positions` is empty after 14:45 and never pushes its own flatten unless the autopilot failed to. |
| close run | Vault | Ledger close (equityClose, dayPnl, each trade's R and dollars), report/main, paperDay (checked against the count of ledger days with orders), then the nightly trade-journal review below. |
| close run | all | One "What I've learned" line each (first and last run of the day), the audit line, crew idle. |
| 14:45 | Autopilot | Flat for the day; day file `done`. |
| 00:25 UTC (7:25 PM CDT, 6:25 PM CST from Nov 1) | Trading lab | Nightly backtest on unseen past days; `readyForLive` = holdout net P/L > $0 with 20+ trades on the CURRENT params; Bull and Bear lab lines. |

### Vault: nightly trade-journal review (part of the close run, after the flatten and the ledger)
1. Read `factory/trading/auto/<day>.json`: `trades[]` (entry, exit, r, why), `actions[]` (times, status codes, qty, stop), `equityOpen` → `equity`, `entries`, `watch`, `avoid`, `lastNote`; exit times from `/orders?status=closed` when the day file has none.
2. Find recurring errors: anything that happened twice today or on 2 of the last 3 journals (read both journal locations). Look for: refused orders (any action with status ≥ 300); exits with why `no stop` or `trail refused`; combined index risk over 2% (the one-bet rule); a −1R stop within 15 minutes of entry; an entry in the last 30 minutes of the window (13:30 to 14:00); a winner sold under 2R without a trailed stop; a name traded while on the avoid list (the 15-minute and 30-minute thresholds were set by Grayson's Oct 23, 2026 review and move only on journal evidence). Quote the times, symbols and numbers from the day file.
3. Write `factory/trading/journal/<day>.md`: the day's numbers (trades, wins/losses, net $, equity open → close, breaches), a trade table (symbol, in, out, R, why, entry time), "Recurring errors" with the evidence, and exactly 3 rules for tomorrow. Each rule names the number it rests on and the check that proves it tomorrow (for example "0 actions with status ≥ 300 in tomorrow's day file"). A rule may tighten, never loosen, a money rule or a LOCKED knob, and never tells the autopilot a price.
4. No-trade day: say so, with the reason from `lastNote`; carry yesterday's 3 rules forward and mark each held / not held. Invent nothing.
5. One dated line in Vault's "What I've learned": the journal file and the single most important rule.
(Until Grayson adds `factory/trading/journal/` to the close task's write list, Vault writes the journal under the skills folder it may already write, `factory/skills/vault/journal-<day>.md`, and says so in the ledger.)

### Autopilot trail-stop fix (Oct 23, 2026)
- **What happened (Oct 22):** both winners (XLF 11:29, WMT 14:35) exited via `trail refused (422) → no stop found → market sell`. The day file shows the refused orders were sent with `qty "0"`: the autopilot took Alpaca's `qty_available`, which is 0 while the protective stop order holds the shares (and the string "0" is truthy, so the fallback to `qty` never ran). The fail-safe market sell went out with `qty "0"` too and was refused, so each name sat without a stop for about one minute until the next cycle sold it.
- **Fix (factory/trading/autopilot.py):** stop re-places and sells use the whole position `qty`; the old stop's cancel is confirmed by reading the order back before the new stop is placed (then the live position qty is re-read); one retry 2 s later; if Alpaca still refuses, the existing fail-safe sells at market with the right qty and the trade is recorded honestly as `trail refused` with its real R; if the old stop filled during the cancel, nothing more is sent. No money rule, LOCKED knob or exit level changed.
- **Verified when:** a paper day's file shows at least one `raise stop` action with a `qty`, no action with status ≥ 300 and no buy with status 207. Until then the fix is "in code, not yet seen live".

### Go-live readiness checklist (the crew may say "ready" only when every box is true; Grayson's separate "live go", live keys and `ALPACA_LIVE=1` set by him are still required after that)
| # | Gate | How it is measured (real data only) | Status Oct 23, 2026 |
|---|---|---|---|
| 1 | Trading lab: holdout net P/L > $0 with 20+ holdout trades and 0 breaches on the CURRENT params | the latest `factory/trading/lab/<id>.json` → `baseline.holdout` (netPnl, trades, breaches; profitFactor is then above 1.0, or `null` if no trade lost) | NOT MET: lab-2026-10-22 holdout 28 trades, 14.3% wins, −$0.54, 0 breaches (profit factor appears from the next lab run) |
| 2 | 0 rule breaches on every paper day | `modules/trading/report/main.breaches` and each ledger's `breaches[]`; every buy got its stop; no order outside 8:35–2:45 CT | read at each close run (lives in the database, not the repo) |
| 3 | 2 clean paper days AFTER the trail-stop fix | a clean day = heartbeat gaps under 30 minutes during market hours, 0 actions with status ≥ 300, 0 exits with why `no stop` or `trail refused`, `/positions` empty after 14:45, ledger and journal written (either journal location), breaches 0, and no buy returned with status 207 (stop refused by Alpaca, position sold at once) | 0 of 2 (the fix lands Oct 23; Oct 23 is the first candidate day) |
| 4 | Trail-stop bug fixed and seen working | a day file with a `raise stop` action carrying a `qty`, no status ≥ 300 and no buy with status 207 | fixed in code Oct 23, 2026; not yet seen live |
The lab's `readyForLive` flag (and the Factory page's "Ready for real money" pill) reads only holdout net > 0 with 20+ trades; gate 1 here also requires 0 holdout breaches and is the authoritative check, so the pill can say yes while this table says no.
"Ready" describes the mechanics and the past-day evidence; it is not a prediction. The account can still lose the $25.

## Notebook (Grayson, Oct 23, 2026)
Every trading run (scans, close, lab) first runs `python3 factory/notebook/nb.py show --lane trading`
and follows its "Grayson's rules" and "Proven" lines. The Night Shift's keeper writes each trading
day's results into the notebook from modules/trading/ledger/<day>; the lab's proven or retired
setups go there too. Past days only; not financial advice.
